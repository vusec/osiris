#!/usr/bin/python

from scipy import stats as scistats
from benchmark import *

class PAUtil:

	@staticmethod
	def RPSIniFilter(ini):
		for sec in ini.iterkeys():
			if 'requests_per_sec' in ini[sec].keys():
				ini[sec]['throughput_deg'] = ini[sec]['requests_per_sec']
			else:
				ini[sec]['throughput_deg'] = map(lambda x:-(1-1/(1+x)),ini[sec]['retr_secs'])
		return ini

	@staticmethod
	def geomean(elements):
		negatives=[e for e in elements if e < 0 ]
		if len(negatives) > 0 or len(elements) == 0:
			return 0
		return (reduce(lambda x, y: x*y, elements))**(1.0/len(elements))

if __name__ == "__main__":

	# Postprocessing
	my_res_path = "output"

	my_out_path="techniques_comparison"
	os.system("mkdir -p %s" % my_res_path)
	res_conf_names = ["Undolog","Undolog_dse_alloca_Opt","Undolog_AllOpt", "Bitmap", "Bitmap_dse_alloca_Opt","Bitmap_AllOpt", "Fork" , "MProtect", "Softdirty" ]
	res_app_names = ["lighttpd", "nginx", "httpd", "vsftpd", "proftpd", "pure-ftpd", "bind", "postgresql"]
	#res_app_names = ["postgresql"]
	res_aggregators = {'geomean' : PAUtil.geomean}
	print(" * Generating output files in %s..." % my_res_path)

	INI.iniFilePostprocessByKey(my_out_path, my_res_path, "Performance-relative", "servers",
		res_conf_names,
		"throughput_deg",
		appNames=res_app_names,
		aggregators=res_aggregators,
		valueFilter=lambda x: 1-max(-x,0),
		iniFilter=PAUtil.RPSIniFilter)

	res_conf_names = [ "Bitmap_AllOpt",  "bitmap.dr.onlylibs", "bitmap.dr.onlylibs_wo_inst", "bitmap.dr"]

	INI.iniFilePostprocessByKey(my_out_path, my_res_path, "Performance-relative", "servers_dr",
		res_conf_names,
		"throughput_deg",
		appNames=res_app_names,
		aggregators=res_aggregators,
		valueFilter=lambda x: 1-max(-x,0),
		iniFilter=PAUtil.RPSIniFilter)

