from benchmark import *

class Conf_LTCKPT(Conf_Generic):
	def __init__(self, name="Baseline", cp_method="baseline", serverctl_env="", buildcp_env=""):
		Conf_Generic.__init__(self, name)
		self.cp_method   = cp_method
		self.run_env     = serverctl_env
		self.buildcp_env = buildcp_env

	def prepare(self):
#		self.ctx.get_app().make_call("./relink.llvm ltckpt")
		self.ctx.get_app().make_call("FORCE_REBUILD=1 LTCKPT_EXTRA_OPTS=\""+self.buildcp_env+"\" CP_METHOD="+self.cp_method+" ./clientctl buildcp")
		self.ctx.app.restart(self.run_env)



if __name__ == "__main__":
	bm = Benchmark([
		Conf_LTCKPT(),
		Conf_LTCKPT("Undolog_AllOpt", cp_method="undolog", buildcp_env="ltckpt_skip_alloca ltckpt_eliminate_double_stores ltckpt_aggregate_struct_stores"),
		Conf_LTCKPT("Bitmap_AllOpt", cp_method="bitmap", buildcp_env="ltckpt_skip_alloca ltckpt_eliminate_double_stores ltckpt_aggregate_struct_stores"),
		],	
		  AppFactory("SPEC@all_c").toApps()
		  #AppFactory("postgres proftpd vsftpd pure-ftpd").toApps()
		  ,
		[
		  Out_Generic(),
		],
		  Bench_Generic("Performance", "CLIENT_CP=1"),
		  num_runs=3,out_path="./spec").start()

