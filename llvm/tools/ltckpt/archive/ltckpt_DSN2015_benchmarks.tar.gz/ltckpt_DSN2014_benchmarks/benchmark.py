import os
import logging
import shutil
import subprocess
import numpy
import urwid
import threading
import sys
import time
import select
import fcntl
import re
import copy

from collections import OrderedDict

try:
    import ConfigParser
except:
    from six.moves import configparser as ConfigParser

FNULL = open(os.devnull,'w')

#
# Utils
#
class Util:
	projectRoot=None

	@staticmethod
	def getProjectRoot():
		if not Util.projectRoot:
			Util.projectRoot=Util.cmdToOut("while ! test -f ./common.inc; do cd ..; done; pwd")
		return Util.projectRoot

	@staticmethod
	def getProjectPath(path):
		return "%s/%s" % (Util.getProjectRoot(), path)

	@staticmethod
	def getAppPaths(nameRegex, pathSuffix=""):
		appsRoot=Util.getProjectPath("apps")
		if nameRegex == "SERVERS":
			lines=Util.cmdToOutLines("find . -maxdepth 2 -mindepth 2 -name serverctl | grep '-' | cut -d'/' -f 2", ":/apps")
		elif nameRegex == "FTPDS":
			lines=Util.getPaths("*ftp*:/")
		elif nameRegex == "HTTPDS":
			lines=Util.getPaths("*http*:/")
			lines.append(Util.getPath("nginx:/"))
		else:
			if "*" not in nameRegex:
				nameRegex += "*" # implicit wildcard
			lines=Util.cmdToOutLines("find . -mindepth 1 -maxdepth 1 -type d -name \"%s\" | cut -d'/' -f 2" % nameRegex, ":/apps")
		appPaths = [ appsRoot + "/" + l + pathSuffix for l in lines]
		return appPaths

	@staticmethod
	def getAppPath(name, path=""):
		appPaths = Util.getAppPaths(name, path)
		if len(appPaths) != 1:
			raise  Exception("Cannot uniquely identify app: "+ name)
		return appPaths[0]

	@staticmethod
	#
	# Sample special paths:
	# :/llvm/passes
	# nginx:/src
	# SERVERS:/serverctl #expands to multiple paths
	#
	def getPaths(pathRegex):
		tokens = pathRegex.split(':/')
		if len(tokens) == 1:
			return pathRegex
		if tokens[0] == '':
			return Util.getProjectPath(tokens[1])
		else:
			return Util.getAppPaths(tokens[0], tokens[1])

	@staticmethod
	def getPath(path):
		tokens = path.split(':/')
		if len(tokens) == 1:
			return path
		if tokens[0] == '':
			return Util.getProjectPath(tokens[1])
		else:
			return Util.getAppPath(tokens[0], tokens[1])

	@staticmethod
	def cmdToOut(cmd, path=None):
		if path:
			cmd = "cd %s && %s" % (Util.getPath(path), cmd)
		handle=subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
		data=handle.communicate()[0].rstrip()
		if handle.returncode != 0:
			raise Exception("Utility command returned error: " + cmd)
		return data

	@staticmethod
	def cmdToOutLines(cmd, path=None):
		return Util.cmdToOut(cmd, path).split(os.linesep)

#
# App management
#
class App_Generic:
	def __init__(self, name, cmdPrefix="", isServer=True):
		self.init(name)
		self.cmdPrefix = cmdPrefix
		self.isServer = isServer
		if isServer:
			self.main_ctl="serverctl"
		else:
			self.main_ctl="clientctl"

	def init(self, name):
		self.name   = name;
		self.path   = Util.getPath("%s:/" % name)

	def info(self, msg):
		logging.debug(self.name + ": "+msg)

	def make_call(self, cmd):
		logging.debug("Executing app cmd: "+cmd) 
		proc=subprocess.Popen(" ( cd "+ self.path + "&& ( " + self.cmdPrefix + " " + cmd +") )",
			stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True,  shell= True, bufsize=128)
		msg = ''
		while proc.poll() is None:
			self.rl = [proc.stdout]
			while proc.stdout in self.rl:
				ret = select.select(self.rl,[],[],1)
				self.rl = ret[0]
				if proc.stdout in self.rl:
					_msg = proc.stdout.read(1)
					if _msg =='':
						break
					if _msg == '\n':
						logging.debug(msg)
						msg = ''
					else:
						msg = msg + _msg
		if msg != '':
				logging.info(msg)
		if proc.poll() != 0:
			raise Exception("Command returned error: " + cmd)

	def relink(self, relink_arg = "NULL"):
		self.info("Relinking...")
		self.make_call("./relink.llvm " +  relink_arg );

	def build(self, build_arg = "", env_str=""):
		self.info("Instrumenting...")
		self.make_call(env_str + "  ./build.llvm " +  build_arg)

	def restart(self, env_str=""):
		return

	def start(self, env_str=""):
		self.restart(env_str)

	def stop(self,  env_str = ""):
		return

	def get_name(self):
		return self.name

class App_Server(App_Generic):
	def __init__(self, name):
		App_Generic.__init__(self, name)

	def restart(self, env_str=""):
		self.info("Restarting...")
		self.make_call(env_str + "  ./serverctl frestart 2>&1 ")

	def stop(self,  env_str = ""):
		self.info("Stopping.")
		self.make_call(env_str + "  ./serverctl stop")

class App_SPEC(App_Generic):
	def __init__(self, name):
		App_Generic.__init__(self, "SPEC", cmdPrefix="C=%s" % name, isServer=False)
		self.name=name

class AppFactory:
	def __init__(self, names):
		self.apps = []
		for n in names.split(' '):
			if n == "SPEC":
				n = "SPEC@all_c"
			tokens = n.split('@')
			if tokens[0] == "SPEC":
				self.apps.extend([App_SPEC(a) for a in Util.cmdToOutLines("C=%s ./clientctl list" % tokens[1], "SPEC:/")])
			else:
				self.apps.extend([App_Server(os.path.basename(a)) for a in Util.getPaths("%s:/" % n)])

	def toApps(self):
		return self.apps

#
# Configuration management
#
class Conf_Generic:
	def __init__(self, name="Baseline"):
		self.name=name
		self.run_env=''
		return

	def setBenchmarkerCtx(self, ctx):
		self.ctx=ctx

	def info(self, msg):
		logging.info(self.name + ": "+msg)

	def prepare(self):
		self.info ("Preparing for Benchmark")
		self.ctx.app.relink()
		self.ctx.app.build()
		self.ctx.app.restart(env_str=self.run_env)

	def finalize(self):
		self.ctx.app.stop(env_str=self.run_env)

	def pre_run_action(self):
		return

	def post_run_action(self):
		self.ctx.app.restart(env_str=self.run_env);
		return

	def get_name(self):
		return self.name

#
# Benchmark management
#
class Bench_Generic:
	def __init__(self,name,run_env=""):
		self.name=name
		self.run_env=run_env
		return

	def setBenchmarkerCtx(self, ctx):
		self.ctx=ctx

	def info(self, msg):
		logging.info(self.name + ": "+msg)

	def pre_run_action(self):
		return

	def prepare(self):
		os.system("sudo sysctl -w net.ipv4.tcp_fin_timeout=15 > /dev/null")
		os.system("sudo sysctl -w net.ipv4.tcp_tw_recycle=1 > /dev/null")
		os.system("sudo sysctl -w net.ipv4.ip_local_port_range='32768 65535' > /dev/null")
		os.system("sudo cpufreq-set -g performance")

		if not self.ctx.get_app().isServer:
			self.run_env = self.run_env + " " + self.ctx.get_config().run_env

		return

	def post_run_action(self):
		return

	def get_result(self):
		self.ctx.app.make_call("cp ./runbench.ini "+self.ctx.get_current_path()+"/"+self.name+".ini");

	def run(self):
		self.info("Running Benchmark for application " 
			+ self.ctx.get_app().get_name() +
			" and configuration "
			+ self.ctx.get_config().get_name() +
			" ("+str(self.ctx.get_current_num()+1)+"/"+str(self.ctx.get_num())+")" )

		self.ctx.app.make_call(self.run_env + " ./clientctl bench 2>&1 | tee clientctl.out")

	def finalize(self):
		os.system("sudo cpufreq-set -g powersave")

	def get_name(self):
		return self.name

#
# Output management

class INI:
	@staticmethod
	def getRunFiles(inputDir, inputName, start, end):
		files = {}
		for i in range(start, end):
			files[i] = (inputDir + "/" +str(i)+"/"+inputName+".ini")
		return files

	@staticmethod
	def getExpFiles(inputDir, inputName):
		files = {}
		inputDir = os.path.abspath(inputDir)
		for d in os.listdir(inputDir):
			if not os.path.isdir(os.path.join(inputDir,d)):
				continue
			path = os.path.join(inputDir,d,inputName+".ini")
			if not os.path.exists(path):
				continue
			files[d] = path
		return files

	@staticmethod
	def filesToInis(files, renameSecTemplate=None):
		inis = []
		for f in files.itervalues():
			inis.append(INI.fileToIni(f, renameSecTemplate))
		return inis

	@staticmethod
	def fileToIni(f, renameSecTemplate=None):
		ini = OrderedDict()
		cp = ConfigParser.SafeConfigParser()
		cp.read(f)
		for sec in cp.sections():
			ini[sec] = OrderedDict()
			for (key,val) in cp.items(sec):
				ini[sec][key]=[float(val)]
		INI.iniSectionWalk(ini, INI.SWalkerCheckLen)
		INI.iniKeyWalk(ini, INI.KWalkerCheckLen)
		if renameSecTemplate:
			ini = INI.iniSectionWalk(ini, INI.SWalkerRename, renameSecTemplate)

		return ini

	@staticmethod
	def dirToIni(sec, dirName, clear=False):
		ini = OrderedDict()
		if not os.path.exists(dirName):
			return ini
		ini[sec] = OrderedDict()
		keys=Util.cmdToOutLines("find . -type f | cut -d'/' -f 2", dirName)
		for key in keys:
			val = Util.cmdToOutLines("cat " + key, dirName)[0]
			ini[sec][key] = [val]
		if clear:
			Util.cmdToOut("find . -type f -exec sh -c 'echo 0 > {}' \;", dirName)
		return ini

	@staticmethod
	def iniFilePostprocessByKey(outDir, resDir, fileName, resFileName, confNames, fieldName, appNames=None, valueFilter=None, iniFilter=None, aggregators={}, isSPEC=False, format="dat"):
		INI.iniFilePostprocess(outDir, resDir, fileName, resFileName, confNames, [fieldName], appNames, valueFilter, iniFilter, aggregators, isSPEC, format)

	@staticmethod
	def iniFilePostprocessByConf(outDir, resDir, fileName, resFileName, confName, fieldNames, appNames=None, valueFilter=None, iniFilter=None, aggregators={}, isSPEC=False, format="dat"):
		INI.iniFilePostprocess(outDir, resDir, fileName, resFileName, [confName], fieldNames, appNames, valueFilter, iniFilter, aggregators, isSPEC, format)

	@staticmethod
	def iniFilePostprocess(outDir, resDir, fileName, resFileName, confNames, fieldNames, appNames=None, valueFilter=None, iniFilter=None, aggregators={}, isSPEC=False, format="dat"):
		if not confNames:
			confNames = Util.cmdToOutLines("find %s -mindepth 2 -maxdepth 2 -type d -exec basename {} \; | sort | uniq" % outDir)
		if not appNames:
			grepArg=""
			if not isSPEC:
				grepArg="-v"
			appNames = Util.cmdToOutLines("find %s -mindepth 1 -maxdepth 1 -type d -exec basename {} \; | sort | uniq | grep %s '^[0-9]'" % (outDir, grepArg))
		confRegex = r"^.*?\.(%s)\..*$" % '|'.join(confNames)
		appRegex = r"^(%s).*$" % '|'.join(appNames)
		keyRegex = r"^(%s)$" % '|'.join(fieldNames)

		ini = INI.fileToIni(outDir + "/" + fileName + ".ini")
		if iniFilter:
			ini = iniFilter(ini)
		yOrder = confNames
		if len(fieldNames)>1:
			yOrder = fieldNames
		tableIni = INI.iniTablify(ini, appRegex, confRegex, keyRegex, xOrder=appNames, yOrder=yOrder)
		with open("%s/%s.%s" % (resDir, resFileName, format), "w") as text_file:
			  text_file.write(INI.tableIniToString(tableIni, format, valueFilter=valueFilter, aggregators=aggregators))

	@staticmethod
	def inisUnify(inis, minLen=1, maxLen=sys.maxsize):
		unifiedIni = OrderedDict()
		for ini in inis:
			for (sec, entries) in ini.iteritems():
				if sec not in unifiedIni:
					unifiedIni[sec] = OrderedDict()
				for (key,vals) in entries.iteritems():
					if key not in unifiedIni[sec]:
						unifiedIni[sec][key] = []
					unifiedIni[sec][key].extend(vals)
		INI.iniKeyWalk(unifiedIni, INI.KWalkerCheckLen, minLen, maxLen)
		return unifiedIni

	@staticmethod
	def iniGetFirstSection(ini):
		return ini.keys()[0]

	@staticmethod
	def iniSetFirstSection(ini, sec):
		newIni = copy.deepcopy(ini)
		oldSec = INI.iniGetFirstSection(newIni)
		newIni[sec] = newIni[oldSec]
		del newIni[oldSec]
		return newIni

	@staticmethod
	def iniSectionGrep(ini, secRegex):
		newIni = copy.deepcopy(ini)
		strippedSecs=[]
		for (sec, entries) in newIni.iteritems():
			if not re.match(secRegex):
				strippedSecs.append(sec)
		for sec in strippedSecs:
			del newIni[sec]
		return newIni

	@staticmethod
	def iniOverrideFirstSection(ini, fromIni):
		sec = INI.iniGetFirstSection(fromIni)
		newIni = INI.iniSetFirstSection(ini, sec)
		for (key,vals) in fromIni[sec].iteritems():
			if key not in newIni[sec]:
				newIni[sec][key] = vals
		return newIni

	@staticmethod
	def iniKeyWalk(ini, callback, *args):
		newIni = OrderedDict()
		for (sec, entries) in ini.iteritems():
			newIni[sec] = OrderedDict()
			for key in entries.iterkeys():
				values = callback(sec, key, ini[sec][key], *args)
				if not isinstance(values, list):
					values = [values]
				INI.KWalkerCheckLen(sec, key, values)
				newIni[sec][key] = values
		return newIni

	@staticmethod
	def iniSectionWalk(ini, callback, *args):
		newIni = OrderedDict()
		for sec in ini.iterkeys():
			(newSec, newEntries) = callback(sec, ini[sec], *args)
			newIni[newSec] = newEntries
		return newIni

	@staticmethod
	def iniPrint(ini):
		INI.iniSectionWalk(ini, INI.SWalkerPrint)

	@staticmethod
	def iniTablify(ini, xSecFieldRegex, ySecFieldRegex, yKeyFieldRegex, sep=',', xOrder=[], yOrder=[], aggregators={}):
		ini = INI.iniSectionWalk(ini, INI.SWalkerGrep, yKeyFieldRegex)
		tableIni = OrderedDict()
		tableIni['table'] = OrderedDict()
		indexYSecs = OrderedDict()
		indexYKeys = OrderedDict()
		hasMultipleYSections=False
		hasMultipleYKeys=False
		#
		# Check for hasMultipleYSections
		#
		for sec in ini.iterkeys():
			xm = re.match(xSecFieldRegex, sec)
			if not xm:
				continue
			x = xm.group(1)
			ym = re.match(ySecFieldRegex, sec)
			if not ym:
				continue
			y = ym.group(1)
			if x not in indexYSecs:
				indexYSecs[x] = OrderedDict()
			indexYSecs[x][y] = 1
			if len(indexYSecs[x]) > 1:
				hasMultipleYSections=True
				break
		#
		# Check for hasMultipleYKeys
		#
		for (sec, entries) in ini.iteritems():
			xm = re.match(xSecFieldRegex, sec)
			if not xm:
				continue
			x = xm.group(1)
			if not re.match(ySecFieldRegex, sec):
				continue
			for (key,vals) in entries.iteritems():
				y = key
				if x not in indexYKeys:
					indexYKeys[x] = OrderedDict()
				indexYKeys[x][y] = 1
				if len(indexYKeys[x]) > 1:
					hasMultipleYKeys=True
					break
		#
		# Can only handle bidimensional tables
		#
		if hasMultipleYSections and hasMultipleYKeys:
			raise Exception("Cannot tablify both by section and by key!")
		#
		# Dump everything in the form tableIni['table']['x,y'] = [value]
		#
		for sec in ini.iterkeys():
			xm = re.match(xSecFieldRegex, sec)
			if not xm:
				continue
			x = xm.group(1)
			ym = re.match(ySecFieldRegex, sec)
			if not ym:
				continue
			y = ym.group(1)
			if not hasMultipleYKeys:
				entries = ini[sec].values()
				if len(entries) == 0:
					entries = [[float('nan')]]
				tableIni['table'][x + sep + y] = entries[0]
			else:
				for (key,vals) in ini[sec].iteritems():
					y = key
					tableIni['table'][x + sep + y] = vals
		#
		# Sort x, y keys if required
		#
		if len(xOrder)>0 or len(yOrder)>0:
			ini = tableIni
			tableIni = OrderedDict()
			for (sec, entries) in ini.iteritems():
				tableIni[sec] = OrderedDict()
				def sort_key(k):
					(x, y) = k.split(',')
					if not x in xOrder:
						xKey = len(xOrder)
					else:
						xKey = xOrder.index(x)
					if not y in yOrder:
						yKey = len(yOrder)
					else:
						yKey = yOrder.index(y)
					return (len(yOrder)+2)*(xKey+1) + (yKey+1)
				sortedKeys = sorted(entries.keys(), key = sort_key)
				for key in sortedKeys:
					tableIni[sec][key] = ini[sec][key]
		return tableIni

	@staticmethod
	def tableIniToString(tableIni, format="dat", sep=",", xFormat="%s", yFormat="%s", cellFormat="%.3f", valueFilter=None, aggregators={}):
		table = OrderedDict()
		sec = INI.iniGetFirstSection(tableIni)
		xHeaders = []
		yHeaders = []
		maxXHeaderLen = 0
		maxValueLen = 0
		#
		# Index xHeaders and compute maxXHeaderLen
		#
		for key in tableIni[sec].iterkeys():
			x = key.split(sep)[0]
			table[x] = OrderedDict()
			maxXHeaderLen = max(maxXHeaderLen, len(xFormat % x))
		#
		# Index yHeaders and values
		#
		for (key,vals) in tableIni[sec].iteritems():
			(x,y) = key.split(sep)
			table[x][y] = vals[0]
			if valueFilter:
				table[x][y] = valueFilter(table[x][y])
			if x not in xHeaders:
				xHeaders.append(x)
			if y not in yHeaders:
				yHeaders.append(y)
			maxValueLen = max(maxValueLen, len(cellFormat % table[x][y]))
			maxValueLen = max(maxValueLen, len(yFormat % y))
		#
		# Fill missing values
		#
		for x in xHeaders:
			for y in yHeaders:
				if not y in table[x]:
					table[x][y]=float('nan')
		#
		# Add aggregated values to the end
		#
		aggr_values = OrderedDict()
		for (x,aggr_func) in aggregators.iteritems():
			if len(yHeaders) == 0:
				continue
			aggr_values[x] = OrderedDict()
			for y in yHeaders:
				yVals = [ table[i][y] for i in xHeaders ]
				aggr_values[x][y] = aggr_func(yVals)
		for (x, ys) in aggr_values.iteritems():
			table[x] = OrderedDict()
			maxXHeaderLen = max(maxXHeaderLen, len(xFormat % x))
			xHeaders.append(x)
			for y in ys.iterkeys():
				table[x][y] = aggr_values[x][y]
		#
		# Format
		#
		if format == "tex":
			yHeaderBegin=""
			cellSep=" & "
			rowEnd=" \\\\" + os.linesep
		elif format == "dat":
			yHeaderBegin="#"
			cellSep="   "
			rowEnd="" + os.linesep
		else:
			raise Exception("Bad format!")
		y0Align = "%%-%ds" % maxXHeaderLen
		yAlign = "%%%ds" % maxValueLen
		#
		# Output headers
		#
		string = y0Align % yHeaderBegin
		for y in yHeaders:
			string += cellSep + (yAlign % (yFormat % y))
		string += rowEnd
		#
		# Output body
		#
		for x in xHeaders:
			string += y0Align % (xFormat % x)
			for y in yHeaders:
				string += cellSep + (yAlign % (cellFormat % table[x][y]))
			string += rowEnd
		return string

	@staticmethod
	def iniToFile(ini, outputDir, outputName):
		fileName = outputDir + "/" + outputName + ".ini"
		cp = ConfigParser.SafeConfigParser()
		for (sec, entries) in ini.iteritems():
			cp.add_section(sec)
			for (key,vals) in entries.iteritems():
				INI.KWalkerCheckLen(sec, key, vals, maxLen=1)
				cp.set(sec, key, str(vals[0]))
		cf = open(fileName, 'w')
		cp.write(cf)
		cf.close()

	@staticmethod
	def KWalkerCheckLen(sec, key, values, minLen=1, maxLen=sys.maxsize):
		if not minLen <= len(values) <= maxLen:
			raise Exception("Bad key (%s) length: %d" % (key, len(values)))
		return values

	@staticmethod
	def KWalkerResize(sec, key, values, minLen=None, maxLen=None, padValue=None):
		assert minLen <= MaxLen
		KWalkerCheckLen(sec, key, values)
		if maxLen and len(values) > maxLen:
			values = values[0:maxLen]
		if minLen and len(values) < minLen:
			if not padValue:
				padValue = values[-1]
			values.extend([padValue] * (minLen - len(values)))
		return values

	@staticmethod
	def KWalkerRelError(sec, key, values):
		INI.KWalkerCheckLen(sec, key, values, 2, 2)
		if values[0] == 0:
			return 0
		return (values[1]-values[0])/values[0]

	@staticmethod
	def KWalkerFilter(sec, key, values, valueFilter):
		return valueFilter(values)

	@staticmethod
	def SWalkerCheckLen(sec, entries, minLen=1, maxLen=sys.maxsize):
		if not minLen <= len(entries) <= maxLen:
			raise Exception("Bad section (%s) length: %d" % (sec, len(entries)))
		return (sec, entries)

	@staticmethod
	def SWalkerPrint(sec, entries):
		print("[%s]" % sec)
		for (key,vals) in entries.iteritems():
			print("%s = %s" % (key, str(vals)))
		return (sec, entries)

	@staticmethod
	def SWalkerGrep(sec, entries, pattern, flags=0):
		newEntries = OrderedDict()
		for key in entries.iterkeys():
			if re.match(pattern, key, flags):
				newEntries[key] = entries[key]
		return (sec, newEntries)

	@staticmethod
	def SWalkerRename(sec, entries, newSec):
		newSec = newSec.replace("#SECTION#", sec)
		return (newSec, entries)

class Out_Generic:
	names = {}

	def __init__(self, name="OUTPUT"):
		if name == "OUTPUT":
			self.suffix=""
		else:
			self.suffix="-" + name
		self.name=name
		if name in Out_Generic.names:
			Out_Generic.names[name] += 1
			self.name= "%s%d" % (self.name, Out_Generic.names[name])
			self.suffix = "%s%d" % (self.suffix, Out_Generic.names[name])
		else:
			Out_Generic.names[name] = 1
		return

	def setBenchmarkerCtx(self, ctx):
		self.ctx=ctx

	def info(self, msg):
		logging.info(self.name + ": "+msg)

	def get_name(self):
		return self.name

	def aggregate_run_results(self, inputDir, inputName):
		files = INI.getRunFiles(inputDir, inputName, 0, self.ctx.num_runs)
		inis = INI.filesToInis(files)
		ini = INI.inisUnify(inis, len(inis), len(inis))
		ini = INI.iniKeyWalk(ini, INI.KWalkerFilter, numpy.median)
		INI.iniToFile(ini, inputDir, inputName+self.suffix)
		self.info("Aggregated results for app " +self.ctx.get_app().get_name())

	def compare_exp_results(self, inputDir, inputName):
		files = INI.getExpFiles(inputDir, inputName)
		otherInis = []
		baselineIni = None
		for (conf,f) in files.iteritems():
			ini = INI.fileToIni(f, "%s.%s.#SECTION#" % (self.ctx.get_app().get_name(), conf))
			if conf == "Baseline":
				baselineIni = ini
			else:
				otherInis.append(ini)

		# calculate the absolute results
		self.compare_exp_abs_results(inputDir, inputName, baselineIni, otherInis)

		# calculate the relative results
		self.compare_exp_rel_results(inputDir, inputName, baselineIni, otherInis)

	def compare_exp_abs_results(self, inputDir, inputName, baselineIni, otherInis):
		inis = otherInis
		if baselineIni:
			inis = [baselineIni] + inis
		if len(otherInis) == 0:
			return
		ini = INI.inisUnify(inis, 1, 1)
		INI.iniToFile(ini, inputDir, inputName+self.suffix)

	def compare_exp_rel_results(self, inputDir, inputName, baselineIni, otherInis):
		if len(otherInis) == 0 or not baselineIni:
			return
		inis = [INI.inisUnify([INI.iniOverrideFirstSection(baselineIni, ini), ini], 2, 2) for ini in otherInis]
		inis = [INI.iniKeyWalk(ini, INI.KWalkerRelError) for ini in inis]
		ini = INI.inisUnify(inis, 1, 1)
		INI.iniToFile(ini, inputDir, inputName+self.suffix+"-relative")

	def finalize_app_results(self, inputDir, inputName):
		inputName+=self.suffix
		findCmdPrefix="find %s -mindepth 2 -maxdepth 2 " % inputDir
		files=Util.cmdToOutLines("%s -name %s\*.ini -exec basename {} \; | sort | uniq" % (findCmdPrefix, inputName))
		for f in files:
			os.system("%s -name %s -exec cat {} \; > %s/%s" % (findCmdPrefix, f, inputDir, f))

#
# Benchmark interface
#
class Benchmark:
	""" A benchmark consists of a set of configurations, applications, and outputs """
	progressfilter=None

	def __init__(self, configs, apps, outputs, bench, out_path="./run_dir", num_runs=3, num_client_runs=None):
		self.out_path = os.environ.get("BENCH_OUTPATH", out_path)
		self.num_runs = os.environ.get("BENCH_RUNS", num_runs)
		if not num_client_runs:
			num_client_runs=self.num_runs
		self.num_client_runs=num_client_runs
		self.configs  = configs
		self.apps     = apps
		self.outputs  = outputs
		self.bench    = bench
		if not Benchmark.progressfilter:
			logFormatter = logging.Formatter("%(asctime)s [%(levelname)-5.5s]  %(message)s")
			rootLogger = logging.getLogger()
			Benchmark.progressfilter = ProgressFilter()
			rootLogger.addFilter(Benchmark.progressfilter)
			fileHandler = logging.FileHandler("output.log")
			fileHandler.setFormatter(logFormatter)
			rootLogger.addHandler(fileHandler)
			consoleHandler = logging.StreamHandler(stream= sys.stdout)
			consoleHandler.setFormatter(logFormatter)
			rootLogger.addHandler(consoleHandler)
			rootLogger.setLevel(logging.DEBUG)
			consoleHandler.setLevel(logging.INFO)
		logging.info("Benchmark '%s' initialized..." % self.bench.get_name())



	def bench_app(self, app):
		for conf in self.configs:
			num_runs=self.num_runs
			if not app.isServer:
				num_runs=self.num_client_runs
			bencher = Benchmarker(conf, app, self.bench, self.out_path, num_runs)
			bencher.run_bench()
			for output in self.outputs:
				output.setBenchmarkerCtx(bencher)
				output.aggregate_run_results(bencher.get_path(), self.bench.get_name())
		for output in self.outputs:
			output.compare_exp_results(self.out_path + "/" + app.get_name(), self.bench.get_name())

	def run_bench(self):
		logging.info("Selected apps: " + ', '.join([a.get_name() for a in self.apps]))
		for app in self.apps:
			logging.info("*****************")
			logging.info("********* Benchmarking app:  " + app.get_name())
			logging.info("*****************")
			self.bench_app(app)
		for output in self.outputs:
			output.finalize_app_results(self.out_path, self.bench.get_name())
		logging.info("")
		logging.info("********* Benchmark done **********")
		logging.info("")

	def clean(self):
		shutil.rmdir(self.out_path)

	def start(self):
		self.run_bench()

class UrwidBenchmark(logging.Handler, Benchmark):
	def __init__(self, configs, apps, bench, out_path="./run_dir", num_runs=3, num_client_runs=None):
		palette = [
			( 'statusbar', 'black', 'white' ),
			( 'log', 'light gray', 'black' )
		]
		logging.Handler.__init__(self)
		Benchmark.__init__(self, configs, apps, bench, out_path, num_runs, num_client_runs)
		log_listbox_content = urwid.SimpleFocusListWalker([urwid.Text("")])
		self.log_listbox = urwid.ListBox(log_listbox_content);
		statusbar = urwid.Text('Statusbar')
		self.status = statusbar
		statusbar = urwid.AttrMap(statusbar, "statusbar")
		frame= urwid.Frame(self.log_listbox, footer= statusbar)
		self.loop = urwid.MainLoop(frame, palette)
		self.log=[]
		self.mutex = threading.Lock()
		self.watchpipe = self.loop.watch_pipe(self.refresh)
		rootLogger = logging.getLogger()
		self.setLevel(logging.INFO)
		rootLogger.addHandler(self)
		self.neededSteps = len(configs) *len(apps) *(num_runs +2)
		self.pb=''


	def emit(self, record):
		self.mutex.acquire()
		message=self.format(record)
		self.log.append(message)
		os.write(self.watchpipe,"x");
		self.mutex.release()


	def refresh(self, data, user_data=None):
		self.mutex.acquire()
		for message in self.log:
			pos = self.log_listbox.focus_position +1
			self.log_listbox.body.insert(pos, urwid.Text(message))
			self.log_listbox.focus_position += 1
		self.log = []
		self.mutex.release()
		pb = Benchmark.progressfilter.get_progress_string(self.neededSteps, 50)
		if pb != self.pb:
			self.status.set_text(pb)
		self.loop.set_alarm_in(1, self.refresh)
		return True


	def start(self):
		print("starting thread")
		thread = threading.Thread(target=self.run_bench).start()
		print("entering main loop")
		self.loop.set_alarm_in(1, self.refresh)
		self.loop.run()

#
# Benchmark implementation
#
class Benchmarker:
	""" A benchmark run consits of one configuration and one application """
	def __init__(self, conf, app, bench , out_path, num_runs):
		self.conf        = conf
		self.app         = app
		self.bench       = bench
		self.num_runs    = num_runs
		self.current_num = 0
		self.out_path    = out_path + "/" + app.get_name() + "/" + conf.get_name()
		self.conf.setBenchmarkerCtx(self)
		self.bench.setBenchmarkerCtx(self)


	def prepare(self):
		""" create the output directories """
		logging.debug("Creating output path for "+self.app.get_name()+"."+self.conf.get_name())
		if not os.path.exists(self.out_path):
			os.makedirs(self.out_path)
		self.fileHandler = logging.FileHandler(self.out_path+"/output.log")
		logging.getLogger().addHandler(self.fileHandler)
		self.conf.prepare()
		self.bench.prepare()


	def finalize(self):
		""" check if run was ok, stop server, cleanup """
		logging.getLogger().removeHandler(self.fileHandler)
		self.conf.finalize()
		self.bench.finalize()

	def check_if_done(self,num):
		path = self.out_path+"/"+str(num)+"/"
		return os.path.isfile(self.out_path+"/"+str(num)+"/run_succeeded")
		

	def run_a_bench(self, num):
		#check if we already ran the benchmark successfully
		if self.check_if_done(num):
			logging.info("Skipping run "+ str(num+1))
			return
		path = self.out_path+"/"+str(num)+"/"
		if not os.path.exists(path):
			os.makedirs(path)
		self.current_path = os.path.abspath(path)
		fileHandler = logging.FileHandler(path+"/output.log")
		logging.getLogger().addHandler(fileHandler)

		self.conf.pre_run_action()
		self.bench.pre_run_action()

		self.bench.run()
		self.bench.get_result()

		self.bench.post_run_action()
		self.conf.post_run_action()
		os.system("date >  " + self.current_path + "/run_succeeded")
		logging.getLogger().removeHandler(fileHandler)


	def run_bench(self):
		logging.info("Running benchmark "
		              + self.bench.get_name()
					  + " for "
					  + self.app.get_name()
					  + " and configuration "
					  + self.conf.get_name())
		logging.info("|Progress|")
		skip_all = reduce(lambda x,y: x and y,  map(self.check_if_done, range(0,self.num_runs)))
		if not skip_all:
			self.prepare()
		for i in range(0, self.num_runs):
			logging.info("|Progress|")
			self.current_num = i
			self.run_a_bench(i)
		logging.info("|Progress|")
		if not skip_all:
			self.finalize()
		logging.info("Benchmark "
		              + self.bench.get_name()
					  + " for "
					  + self.app.get_name()
					  + " and configuration "
					  + self.conf.get_name()
					  + " done.")


	def get_config(self):
		return self.conf


	def get_app(self):
		return self.app


	def get_bench(self):
		return self.bench


	def get_path(self):
		return os.path.abspath(self.out_path)


	def get_current_path(self):
		return os.path.abspath(self.current_path)


	def get_current_num(self):
		return self.current_num


	def get_num(self):
		return self.num_runs


class ProgressFilter(logging.Filter):
	def __init__(self):
		self.progress = 0

	def filter(self, record):
		if record.getMessage().startswith("|Progress|"):
			self.progress += 1
			return False
		return True

	def get_progress(self):
		return self.progress

	def get_progress_string(self, max, l):
		p = (self.progress/float(max))
		d = int(p*l)
		ret = "|" + "#"*d+"-"*(int(l-d))+"|"
		return ret

